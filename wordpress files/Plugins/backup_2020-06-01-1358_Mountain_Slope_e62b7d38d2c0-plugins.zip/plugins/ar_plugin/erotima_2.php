<?php
function get_similarBought($category, $products, $num_posts){
$args = array(
   'post_type'      => 'product',
   'post_status'    => 'publish',
   'posts_per_page' =>  $num_posts,
   'meta_key'       => 'total_sales',
   'orderby'        => 'meta_value_num',
   'order'          =>  'DESC',
   'tax_query'      =>  array(
      'relation' => AND,
      array(
          'taxonomy' => 'product_cat',
          'field'    => 'slug',
          'terms'    =>  $category
      ),
      array(
           'taxonomy'  => 'products',
            'field'    => 'term_id',
            'terms'    =>  $products,
            'operator' =>  'NOT IN'

      ),

   ),
   
);

}

function user_cartItems($num_posts) { //προιοντα που ειναι στο καλαθι
   $prodID = array();
   $product_cat = array();

    if ( ! WC()->cart->is_empty() ) { //αν το καλαθι δεν ειναι αδειο
        
        foreach(WC()->cart->get_cart() as $cart_item ) { //για καθε προιον που υπαρχει στο καλαθι
            // Handling also variable products and their products variations         
  	       //global $product;  
  	       $prodID[] = $cart_item['product_id'];   
           $terms = get_the_terms( $product_id, 'product_cat' );
			foreach ($terms as $term) { //παιρνουμε την κατηγορια του προιοντος
			   $product_cat[] = $term->name;
			}

			echo $product_cat ;
        	         
     }
     $product_cat = array_unique($product_cat); //βγάλε τα διπλοτυπα

  }
  $overal_prodID = get_userOrders($prodID);
  $finalProd = get_similarBought($product_cat, $overal_prodID, $num_posts);
  var_dump($finalProd);
  return $finalProd;
 
}

function get_userOrders($prodID){
	global $uID;
	$uID = get_current_user_id();
	$args = array(
    'customer_id' => $uID
   );
   $orders = wc_get_orders($args); //παρε ολες τις παραγγελιες απο το συγκεκριμενο χρηστη
   //$order = wc_get_order( $order_id );
   foreach($orders as $order){ //για καθε παραγγελια
	   $items = $order->get_items();
	   foreach ( $items as $item ) {
		   
		    $product_id = $item->get_product_id(); //παρε το product id
		    $prodID[] = $product_id;
		    //$product_variation_id = $item->get_variation_id();
	   }
 }
 $prodID = array_unique($prodID);
 return $prodID;
}

function shortcode_create_mostSimilarBought($num_posts){    
    user_cartItems($num_posts);
    
    
    
}