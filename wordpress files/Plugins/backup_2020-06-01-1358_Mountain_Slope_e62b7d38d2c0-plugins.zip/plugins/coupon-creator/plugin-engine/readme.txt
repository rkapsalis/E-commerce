=== Plugin Engine ===

== Changelog ==

= 3.0.1 January 28th, 2020 =
* Tweak - Update lucatume/di52 to 2.0.12 to prevent conflicts with The Events Calendar 5.0

= 3.0 August 14th, 2019 =
* Add - Plugin Dependency Checker to prevent incompatible versions from loading
* Tweak - Increase minimum PHP version to 5.6 and WordPress 4.9

= 2.5.6 March 11th, 2019 =
* Add - A filter on coupon content to use to modify the allowed tags