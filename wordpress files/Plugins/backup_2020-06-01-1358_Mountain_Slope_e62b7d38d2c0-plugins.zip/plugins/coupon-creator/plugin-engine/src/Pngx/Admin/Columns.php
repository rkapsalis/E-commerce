<?php
// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( class_exists( 'Pngx__Admin__Columns' ) ) {
	return;
}

/**
 * Class Pngx__Admin__Columns
 * CPT Customized Admin Columns
 */
class Pngx__Admin__Columns {


}